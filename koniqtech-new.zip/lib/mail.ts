import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

// 🔥 Generic email sender (reusable)
export async function sendEmail({
  to,
  subject,
  html,
}: {
  to: string;
  subject: string;
  html: string;
}) {
  try {
    const res = await resend.emails.send({
      from: "KoniqTech <onboarding@koniqtech.com>", // ⚠️ replace with your verified domain
      to,
      subject,
      html,
    });

    console.log("EMAIL SENT:", res);

    return res;
  } catch (err) {
    console.error("EMAIL ERROR:", err);
    throw err;
  }
}

// 🔥 Cold outreach email (your use-case)
export async function sendColdEmail(to: string, name?: string) {
  try {
    const res = await resend.emails.send({
      from: "KoniqTech <onboarding@yourdomain.com>", // ⚠️ must be verified in Resend
      to,
      subject: "Quick question 👀",
      html: `
        <p>Hi ${name || "there"},</p>
        <p>I came across your profile and wanted to connect.</p>
        <p>We help companies generate leads automatically.</p>
        <p>Would love to show you how it works.</p>
        <p>Interested?</p>
      `,
    });

    console.log("COLD EMAIL SENT:", res);

    return res;
  } catch (err) {
    console.error("COLD EMAIL ERROR:", err);
    throw err;
  }
}