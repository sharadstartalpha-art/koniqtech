import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { hasRole, ROLES } from "@/lib/permissions";


export async function GET() {
 const users = await prisma.user.findMany({
  where: {
    role: "USER", // ✅ only users
  },
});

  return NextResponse.json(users);
}
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);

 if (!session || !hasRole(session.user.role, [ROLES.OWNER, ROLES.ADMIN])) {
  return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
}

  const { userId, action, value } = await req.json();

  if (action === "ban") {
  await prisma.user.update({
    where: { id: userId },
    data: { isBanned: true },
  });
}

if (action === "unban") {
  await prisma.user.update({
    where: { id: userId },
    data: { isBanned: false },
  });
}

  if (action === "role") {
    await prisma.user.update({
      where: { id: userId },
      data: { role: value },
    });
  }

  if (action === "plan") {
    await prisma.user.update({
      where: { id: userId },
      data: { plan: value },
    });
  }

  return NextResponse.json({ success: true });
}