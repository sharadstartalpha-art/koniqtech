"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { useState, useRef, useEffect } from "react";
import { usePathname } from "next/navigation";
import TeamSwitcher from "@/components/TeamSwitcher";
import NotificationBell from "@/components/NotificationBell";

export default function Navbar() {
  const { data: session } = useSession();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  const isAdminPage = pathname.startsWith("/admin");
  const isAdmin = session?.user?.role === "ADMIN";

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }

    document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, []);

  return (
    <div className="w-full border-b bg-white px-6 py-3 flex justify-between items-center">

      <Link href="/" className="font-bold text-lg">
        KoniqTech 🚀
      </Link>

      <div className="flex items-center gap-5">

        {!isAdmin && session && <TeamSwitcher />}

        {!isAdminPage && (
          <Link href="/pricing" className="text-sm hover:text-gray-600">
            Pricing
          </Link>
        )}

        {session ? (
          <>
            <Link href="/dashboard" className="text-sm">
              Dashboard
            </Link>

            {session.user?.id && (
              <NotificationBell userId={session.user.id} />
            )}

            <div ref={ref} className="relative">
              <button
                onClick={() => setOpen(!open)}
                className="bg-gray-100 px-3 py-1 rounded-lg text-sm"
              >
                {session.user.email}
              </button>

              {open && (
                <div className="absolute right-0 mt-2 w-56 bg-white border rounded-xl shadow-lg p-3 z-50">

                  <p className="text-sm mb-2 text-gray-500">
                    {session.user.email}
                  </p>

                  <Link
                    href="/change-password"
                    className="block px-2 py-1 hover:bg-gray-100 rounded"
                  >
                    Change Password
                  </Link>

                  <button
                    onClick={() => signOut({ callbackUrl: "/" })}
                    className="w-full mt-3 bg-red-500 text-white py-2 rounded-lg"
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          <>
            <Link href="/login">Login</Link>

            <Link
              href="/register"
              className="bg-black text-white px-5 py-2 rounded-lg whitespace-nowrap"
            >
              Get Started
            </Link>
          </>
        )}
      </div>
    </div>
  );
}