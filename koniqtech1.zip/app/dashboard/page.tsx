import { getServerSession } from "next-auth"
import { authOptions } from "../../lib/auth"
import { prisma } from "../../lib/prisma"

export default async function Dashboard() {
  const session = await getServerSession(authOptions)

  if (!session || !session.user?.email) {
    return <div className="p-10">Not logged in</div>
  }

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  })

  if (!user) {
    return <div className="p-10">User not found</div>
  }

  const projects = await prisma.project.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    include: { product: true }, // ✅ show product
  })

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p className="text-gray-600 mb-6">
        Welcome {session.user.email}
      </p>

      {/* ✅ CREATE PROJECT */}
      <form action="/api/projects" method="POST" className="flex gap-2 mb-6">
  <input
    name="name"
    placeholder="New project name"
    className="border p-2 flex-1 rounded"
    required
  />

  {/* ✅ FIXED HERE */}
  <select name="productSlug" className="border p-2 rounded" required>
    <option value="">Select product</option>
    <option value="meeting-ai">Meeting AI</option>
    <option value="lead-finder">Lead Finder</option>
    <option value="automation-tool">Automation Tool</option>
  </select>

  <button className="bg-black text-white px-4 py-2 rounded">
    Create
  </button>
</form>

      {/* ✅ PROJECT LIST */}
      <div className="space-y-3">
        {projects.length === 0 && (
          <p className="text-gray-500">No projects yet</p>
        )}

        {projects.map((project) => (
          <div
            key={project.id}
            className="border rounded p-3 flex justify-between items-center"
          >
            <div>
              <p className="font-medium">{project.name}</p>

              {/* ✅ PRODUCT NAME */}
              <p className="text-sm text-gray-500">
                {project.product.name}
              </p>

              <p className="text-xs text-gray-400">
                {new Date(project.createdAt).toLocaleString()}
              </p>
            </div>

            {/* DELETE */}
            <form action={`/api/projects/${project.id}`} method="POST">
              <button className="text-red-500 hover:underline">
                Delete
              </button>
            </form>
          </div>
        ))}
      </div>
    </div>
  )
}